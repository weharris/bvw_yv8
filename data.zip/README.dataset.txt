# kk-weevils > 2023-07-09 11:10pm
https://universe.roboflow.com/kkweevils/kk-weevils

Provided by a Roboflow user
License: CC BY 4.0

